window.addEventListener("load", () => {
    document.getElementById("titulo").classList.add("show");
     document.getElementById("paragrafo").classList.add("show");
});